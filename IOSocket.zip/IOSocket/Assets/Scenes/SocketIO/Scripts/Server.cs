﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SocketIO;
using System;

public class Server : MonoBehaviour
{
    // Start is called before the first frame update
    private SocketIOComponent socket;
    void Start()
    {
        GameObject go = GameObject.Find("SocketIO");
        socket = go.GetComponent<SocketIOComponent>();
        socket.On("Receive_Data", ReceiveData);
    }

    private void ReceiveData(SocketIOEvent obj)
    {
        
        if (obj.data == null) { return; }
        Debug.Log("[SocketIO] user has sent: " + obj.name + "_" + obj.data);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
