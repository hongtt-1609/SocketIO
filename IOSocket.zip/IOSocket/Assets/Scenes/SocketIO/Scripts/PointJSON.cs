﻿public class PointJSON
{
}