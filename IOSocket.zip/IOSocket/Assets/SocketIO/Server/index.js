var app = require('express')();
var server = require('http').Server(app);
var io = require('socket.io')(server);

server.listen(4567);

app.get('/',function(req,res){
	res.send('hey you got back yet "/"');
})

console.log('---server is running...')