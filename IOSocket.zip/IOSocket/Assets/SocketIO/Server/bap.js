var io = require('socket.io')({
	transports: ['websocket'],
});

io.attach(4567);

